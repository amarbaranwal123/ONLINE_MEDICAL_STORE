
$(".slider-one").slick({
	autoplay: true,
	autoplaySpeed: 3000,
	dots: true

});
